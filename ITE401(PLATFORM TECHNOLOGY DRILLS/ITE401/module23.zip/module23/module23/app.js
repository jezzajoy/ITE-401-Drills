const locationInput = document.getElementById("locationInput");
const addLocationButton = document.getElementById("addLocationButton");
const locationList = document.getElementById("locationList");
const mapContainer = document.getElementById("mapContainer"); // Add a container for the map

// Initialize the map
let map = L.map(mapContainer).setView([0, 0], 2); // Default view (world map)
L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
}).addTo(map);

addLocationButton.addEventListener("click", async () => {
    const newLocation = locationInput.value.trim();

    if (newLocation) {
        locationInput.value = ""; // Clear input field

        const listItem = document.createElement("li");
        listItem.innerHTML = `<strong>${newLocation}</strong><br>
                              <span class="coordinates">Fetching location...</span>`;

        locationList.appendChild(listItem);

        try {
            // Fetch location coordinates using OpenStreetMap (Nominatim API)
            const locationResponse = await fetch(
                `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(newLocation)}`
            );

            if (!locationResponse.ok) {
                throw new Error(`Network response was not ok: ${locationResponse.status}`);
            }

            const locationData = await locationResponse.json();

            if (locationData.length > 0) {
                const { lat, lon } = locationData[0];
                listItem.querySelector(".coordinates").textContent = `Lat: ${lat}, Lon: ${lon}`;

                // Update the map view and add a marker
                const latLng = [parseFloat(lat), parseFloat(lon)];
                map.setView(latLng, 13); // Zoom in on the location
                L.marker(latLng).addTo(map).bindPopup(`<strong>${newLocation}</strong>`).openPopup();
            } else {
                listItem.querySelector(".coordinates").textContent = "Location not found.";
            }
        } catch (error) {
            console.error("Error fetching location:", error);
            listItem.querySelector(".coordinates").textContent = "Error fetching location.";
        }
    }
});
