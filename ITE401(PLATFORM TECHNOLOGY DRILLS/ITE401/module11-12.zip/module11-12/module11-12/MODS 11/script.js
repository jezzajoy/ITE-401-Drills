document.getElementById('send-button').addEventListener('click', sendMessage);

function sendMessage() {
    const messageInput = document.getElementById('message-input');
    const message = messageInput.value.trim();
    const chatMessages = document.getElementById('chat-messages');

    if (message) {
        // Display the user's message
        const userMessage = document.createElement('div');
        userMessage.className = 'message outgoing';
        userMessage.textContent = message;
        chatMessages.appendChild(userMessage);

        // Check for specific queries
        if (message.toLowerCase() === 'where is ui') {
            const botMessage = document.createElement('div');
            botMessage.className = 'message incoming';
            botMessage.textContent = 'Here is the location of PHINMA - University of Iloilo.';
            chatMessages.appendChild(botMessage);

            // Update the map iframe source
            const mapIframe = document.getElementById('map-iframe');
            mapIframe.src = 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3920.550913468192!2d122.56701887410357!3d10.691923960748593!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x33aee5255345f116%3A0xb32057bb6b1d39c8!2sPHINMA%20University%20of%20Iloilo!5e0!3m2!1sen!2sph!4v1690769915321!5m2!1sen!2sph';
        }

        // Clear the input field
        messageInput.value = '';
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }
}

