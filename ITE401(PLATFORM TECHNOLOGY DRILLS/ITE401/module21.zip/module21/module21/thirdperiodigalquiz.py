import json

def store_places():
    places = []
    while True:
        place = input("Enter a place (or 'q' to quit): ")
        if place.lower() == 'q':
            break
        places.append(place)
    
    places_json = json.dumps(places, indent=4)
    print("\nAll places entered:")
    print(places_json)
    return places

def get_bot_response(user_message, places):
    responses = {
        "hello": "Hello! How can I help you today?",
        "bye": "Goodbye! Have a great day!",
    }
    
    user_message = user_message.lower()
    
    if user_message in responses:
        return responses[user_message]
    elif user_message.startswith("tell me about "):
        place_name = user_message.replace("tell me about ", "").strip()
        if place_name in places:
            return f"{place_name} is one of the places you entered."
        else:
            return "I don't have information on that place."
    else:
        return "I'm not sure how to respond to that."

def main():
    print("Welcome! First, enter some places.")
    places = store_places()
    print("\nNow, you can ask me about the places you entered.")
    
    while True:
        user_input = input("You: ")
        if user_input.lower() == "bye":
            print("Chatbot: Goodbye!")
            break
        response = get_bot_response(user_input, places)
        print(f"Chatbot: {response}")

if __name__ == "__main__":
    main()
