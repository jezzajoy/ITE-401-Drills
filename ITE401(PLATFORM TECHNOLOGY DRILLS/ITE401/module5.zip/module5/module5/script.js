const container = document.getElementById('data-container');

// Replace with Google Books API endpoint
fetch('https://www.googleapis.com/books/v1/volumes?q=javascript') // Example query for "javascript"
    .then(response => response.json())
    .then(data => {
        container.innerHTML = '<h2>Books Fetched Successfully!</h2>';
        data.items.forEach(item => {
            const book = document.createElement('div');
            book.innerHTML = `<h3>${item.volumeInfo.title}</h3><p>${item.volumeInfo.authors?.join(', ') || 'Unknown Author'}</p>`;
            container.appendChild(book);
        });
    })
    .catch(error => {
        container.innerHTML = '<h2>Error Fetching Data!</h2>';
        console.error("Fetch error:", error);
    });
