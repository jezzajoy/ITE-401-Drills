function handleSubmit(event) {
    event.preventDefault();
    alert("Your survey has been recorded");
    event.target.reset();
}